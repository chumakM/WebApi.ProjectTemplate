﻿namespace $ext_safeprojectname$.BL
{
    /// <summary>
    /// Слой бизнес логики для теста
    /// </summary>
    public interface ITestLogic
    {
        /// <summary>
        /// Тестовый метод логики
        /// </summary>
        /// <returns></returns>
        string DataFromTest();
    }
}