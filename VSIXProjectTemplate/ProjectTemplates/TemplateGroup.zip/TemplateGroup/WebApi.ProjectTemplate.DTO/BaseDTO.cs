﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace $safeprojectname$
{
    /// <summary>
    /// Базовый класс для DTO
    /// </summary>
    public class BaseDTO
    {
        /// <summary> Копирование значений свойств из источника через рефлексию </summary>
        /// <typeparam name="S">Тип источника</typeparam>
        /// <param name="source">Источник значений</param>
        public void CopyFrom<S>(S source)
        {
            if (null == source) return;

            var typeSource = source.GetType();
            var typeTarget = this.GetType();

            var trgFields = (from pr in typeTarget.GetFields() select pr.Name).ToList();
            foreach (var sourceField in typeSource.GetFields())
            {
                if (trgFields.Contains(sourceField.Name))
                {
                    var targetField = typeTarget.GetField(sourceField.Name);
                    targetField.SetValue(this, sourceField.GetValue(source));
                }
            }

            var trgProps = (from pr in typeTarget.GetProperties() select pr.Name).ToList();
            foreach (var sourceProperty in typeSource.GetProperties())
            {
                if (trgProps.Contains(sourceProperty.Name))
                {
                    var targetProperty = typeTarget.GetProperty(sourceProperty.Name);

                    if (targetProperty?.PropertyType.FullName == sourceProperty.PropertyType.FullName)
                        targetProperty.SetValue(this, sourceProperty.GetValue(source, null), null);
                }
            }
        }

        /// <summary> Копирование значений свойств в целевой объект </summary>
        /// <typeparam name="T">Тип целевого объекта</typeparam>
        /// <param name="target">Целевой объект</param>
        /// <param name="skipPropNames">Названия свойств, которые надо пропускать</param>
        /// <returns>Заполненный целевой объект</returns>
        public T SaveTo<T>(T target, string[] skipPropNames = null)
        {
            if (null == target) return target;

            IList<string> skipNames = skipPropNames != null ? skipPropNames.Select(s => s.ToLower()).ToList() : new List<string>();

            var typeSource = this.GetType();
            var typeTarget = target.GetType();

            var trgFileds = (from pr in typeTarget.GetFields() select pr.Name).ToList();
            foreach (var sourceField in typeSource.GetFields())
            {
                if (trgFileds.Contains(sourceField.Name) && !skipNames.Contains(sourceField.Name.ToLower()))
                {
                    FieldInfo? targetField = typeTarget.GetField(sourceField.Name);
                    targetField.SetValue(target, sourceField.GetValue(this));
                }
            }

            var trgProps = (from pr in typeTarget.GetProperties() select pr.Name).ToList();
            foreach (var sourceProperty in typeSource.GetProperties())
            {
                if (trgProps.Contains(sourceProperty.Name) && !skipNames.Contains(sourceProperty.Name.ToLower()))
                {
                    PropertyInfo? targetProperty = typeTarget.GetProperty(sourceProperty.Name);
                    targetProperty.SetValue(target, sourceProperty.GetValue(this, null), null);
                }
            }

            return target;
        }

        /// <summary> Проверка на идентичность </summary>
        /// <param name="obj">Объект - цель проверки</param>
        /// <returns>Да - совпадают, нет - не совпадают</returns>
        public override bool Equals(object obj)
        {
            if (obj != null)
            {
                Type objType = obj.GetType();
                if (objType == this.GetType())
                {
                    PropertyInfo idProp = objType.GetProperty("Id");
                    if (idProp != null && idProp.PropertyType == typeof(Int32))
                    {
                        int thatId = (int)idProp.GetValue(obj);
                        int thisId = (int)idProp.GetValue(this);
                        return thatId == thisId;
                    }
                }
            }
            return base.Equals(obj);
        }

        /// <summary> Хэш-код объекта </summary>
        /// <returns></returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
}
