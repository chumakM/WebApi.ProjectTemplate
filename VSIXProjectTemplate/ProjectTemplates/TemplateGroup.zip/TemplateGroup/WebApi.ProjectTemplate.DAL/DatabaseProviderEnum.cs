﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $ext_safeprojectname$.DAL
{
    /// <summary> Перечисление провайдеров для доступа к базам данных </summary>
    public enum DatabaseProviderEnum
    {
        /// <summary> Провайдер для базы Test </summary>
        test = 1
    }
}
