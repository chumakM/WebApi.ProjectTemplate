﻿namespace $ext_safeprojectname$.DAL.Repositories
{
    public interface ITestRepository
    {
        string DataFromTest();
    }
}