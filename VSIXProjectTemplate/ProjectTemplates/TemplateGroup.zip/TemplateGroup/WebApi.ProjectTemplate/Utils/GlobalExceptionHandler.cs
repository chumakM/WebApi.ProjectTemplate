﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using System.Net;
using Newtonsoft.Json;

namespace $safeprojectname$.Utils
{
    /// <summary>
    /// Глобальный обработчик ошибок
    /// </summary>
    public static class GlobalExceptionHandler
    {
        /// <summary>
        /// Регистрация обработчика
        /// </summary>
        /// <param name="app">Приложение</param>
        /// <param name="logger">Логгер</param>
        public static void ConfigureExceptionHandler(this IApplicationBuilder app, Serilog.ILogger logger)
        {
            app.UseExceptionHandler(appError =>
            {
                appError.Run(async context =>
                {
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    context.Response.ContentType = "application/json";
                    var contextFeature = context.Features.Get<IExceptionHandlerFeature>();
                    if(contextFeature != null)
                    {
                        logger.Error(contextFeature.Error, $"Unhadled exception: {contextFeature.Error.Message}");
                        await context.Response.WriteAsync(new ErrorDetails(context.Response.StatusCode, "Internal Server Error").ToString());
                    }
                });
            });
        }
    }
    /// <summary>
    /// Ошибка выдается в ответ на Exception
    /// </summary>
    public class ErrorDetails
    {
        /// <summary>
        /// Код статуса ошибки
        /// </summary>
        public int StatusCode { get; set; }
        /// <summary>
        /// Сообщение об ошибке
        /// </summary>
        public string Message { get; set; }
        /// <summary>
        /// Конструктор
        /// </summary>
        /// <param name="statusCode">Код статуса ошибки</param>
        /// <param name="message">Сообщение об ошибке</param>
        public ErrorDetails(int statusCode, string message)
        {
            StatusCode = statusCode; ;
            Message = message;
        }
        /// <summary>
        /// Строковое представление
        /// </summary>
        /// <returns>Json-строка</returns>
        public override string ToString() => JsonConvert.SerializeObject(this);
    }
}
